def lamdafunction(event, context):
    return {
        'statusCode': 200,
        'body': 'Hello from Terraform for lamdafunction!'
    }
